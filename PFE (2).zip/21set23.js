let numero = 0;

while (numero <= 10) {
  console.log("o numero agora é:" +numero);
   numero = numero + 1;
  if(numero == 5){
    break;
  }
}