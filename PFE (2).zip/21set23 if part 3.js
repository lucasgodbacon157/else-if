hora = 13;
console.log("hora agora é: " + hora);

if (hora<= 12) {
  console.log("bom dia! amor");
} else if (hora <= 18) {
  console.log ("boa tarde! amor");
} else {
  console.log("boa noite! amor");
}
