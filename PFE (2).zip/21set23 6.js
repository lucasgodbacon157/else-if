let numeroAleatorio = Math.floor(Math.random()* 10) + 1;
let palpite;
while (true){
  palpite = parseInt(prompt("adivinhe um numero entre 1 e 10:"));
  if (palpite === numeroAleatorio){
    alert("parabens! voce acertou.");
    break;
  } else{
    alert("tente novamente! - o numero sorteado foi: " + numeroAleatorio);
  }
}