let hora = 12;

if (hora <= 12){
  console.log( "bom dia!");
}