let frutas = ['maca', 'banana', 'laranja'];

console.log("_ _ _ _ Lista inicial _ _ _ _");
console.log(frutas)

console.log("_ _ _ _ remover o ultimo elemento da lista _ _ _ _")
frutas.pop(); //remove o  ultimo elemento 'laranja';
console.log(frutas)

console.log("_ _ _ _ remover o primeiro elemento _ _ _ _");
frutas.shift(); //remove o primeiro elemento'maça';
console.log(frutas);

console.log("_ _ _ _ adicionar novos elementos no final _ _ _ _");
frutas.push('uvas'); //adiciona o elemento 'uva';
frutas.push('manga') //adiciona o elemento 'manga';
console.log(frutas);

console.log("_ _ _ _ adicionar novos elementos ao inicio _ _ _ _ ");
frutas.unshift('pessego'); //adicionar elemento 'pessego';
frutas.unshift('ameixa'); //adicionar elemento 'ameixa';
console.log(frutas);

console.log("_ _ _ _ removendo elementos de uma determinada posiçao _ _ _ _");
frutas.splice(0, 2); //remove a partir da posiçao 0, dois elementos;
console.log(frutas);