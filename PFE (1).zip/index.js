hora = 3;
console.log("hora agora é: " + hora);

if (hora <= 12) {
  console.log("bom dia!");
} else if (hora <= 18) {
  console.log ("boa tarde!");
} else  if ( hora <= 23){
  console.log("boa noite!");
} else if ( hora <= 6){
  console.log("boa madrugada!")
}
